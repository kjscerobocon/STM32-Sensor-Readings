/* TFLI2C for STM32 (HAL, plain C) - port of Bud Ryerson's Arduino library.
 * Addresses are plain 7-bit values (0x10, 0x12 ...); the <<1 shift for HAL
 * is done inside the library.
 */
#ifndef TFLI2C_H
#define TFLI2C_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "main.h"   /* CubeMX main.h pulls in the HAL header for your family */

#define TFL_DEF_ADR   0x10
#define TFL_DEF_FPS   0x64

/* Registers */
#define TFL_DIST_LO        0x00
#define TFL_DIST_HI        0x01
#define TFL_FLUX_LO        0x02
#define TFL_FLUX_HI        0x03
#define TFL_TEMP_LO        0x04
#define TFL_TEMP_HI        0x05
#define TFL_TICK_LO        0x06
#define TFL_TICK_HI        0x07
#define TFL_ERR_LO         0x08
#define TFL_ERR_HI         0x09
#define TFL_VER_REV        0x0A
#define TFL_VER_MIN        0x0B
#define TFL_VER_MAJ        0x0C
#define TFL_SAVE_SETTINGS  0x20
#define TFL_SOFT_RESET     0x21
#define TFL_SET_I2C_ADDR   0x22
#define TFL_SET_TRIG_MODE  0x23
#define TFL_TRIGGER        0x24
#define TFL_DISABLE        0x25   /* 0 = disable, 1 = enable */
#define TFL_FPS_LO         0x26
#define TFL_FPS_HI         0x27
#define TFL_SET_LO_PWR     0x28
#define TFL_HARD_RESET     0x29

#define FPS_1    0x01
#define FPS_2    0x02
#define FPS_5    0x05
#define FPS_10   0x0A
#define FPS_35   0x23
#define FPS_50   0x32
#define FPS_100  0x64
#define FPS_125  0x7D
#define FPS_250  0xFA

/* Status codes */
#define TFL_READY      0
#define TFL_SERIAL     1
#define TFL_HEADER     2
#define TFL_CHECKSUM   3
#define TFL_TIMEOUT    4
#define TFL_PASS       5
#define TFL_FAIL       6
#define TFL_I2CREAD    7
#define TFL_I2CWRITE   8
#define TFL_I2CLENGTH  9
#define TFL_WEAK      10
#define TFL_STRONG    11
#define TFL_FLOOD     12
#define TFL_MEASURE   13
#define TFL_INVALID   14

typedef struct {
    I2C_HandleTypeDef *hi2c;
    uint32_t           timeoutMs;
    uint8_t            tfStatus;
    HAL_StatusTypeDef  halStatus;
    uint8_t            regReply;
} TFLI2C_t;

/* Attach an already-initialised I2C handle (call after MX_I2Cx_Init()). */
bool TFLI2C_Begin(TFLI2C_t *dev, I2C_HandleTypeDef *hi2c, uint32_t timeoutMs);

/* True if some device ACKs this address (touches no TF-Luna registers). */
bool TFLI2C_IsPresent(TFLI2C_t *dev, uint8_t addr);

/* dist: cm, flux: signal strength, temp: 0.01 C.
 * Returns false on comm error (outputs untouched) or weak/saturated signal
 * (outputs filled, but distance must not be trusted). */
bool TFLI2C_GetDataFull(TFLI2C_t *dev, int16_t *dist, int16_t *flux,
                        int16_t *temp, uint8_t addr);
bool TFLI2C_GetData(TFLI2C_t *dev, int16_t *dist, uint8_t addr);

bool TFLI2C_ReadReg(TFLI2C_t *dev, uint8_t reg, uint8_t addr);
bool TFLI2C_WriteReg(TFLI2C_t *dev, uint8_t reg, uint8_t addr, uint8_t data);

bool TFLI2C_Get_Firmware_Version(TFLI2C_t *dev, uint8_t ver[3], uint8_t addr);
bool TFLI2C_Get_Frame_Rate(TFLI2C_t *dev, uint16_t *frm, uint8_t addr);
bool TFLI2C_Get_Prod_Code(TFLI2C_t *dev, uint8_t cod[14], uint8_t addr);
bool TFLI2C_Get_Time(TFLI2C_t *dev, uint16_t *tim, uint8_t addr);

bool TFLI2C_Set_Frame_Rate(TFLI2C_t *dev, uint16_t frm, uint8_t addr);
bool TFLI2C_Set_I2C_Addr(TFLI2C_t *dev, uint8_t newAddr, uint8_t addr); /* reboot to apply */
bool TFLI2C_Set_Enable(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Set_Disable(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Soft_Reset(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Hard_Reset(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Save_Settings(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Set_Trig_Mode(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Set_Cont_Mode(TFLI2C_t *dev, uint8_t addr);
bool TFLI2C_Set_Trigger(TFLI2C_t *dev, uint8_t addr);

const char       *TFLI2C_GetStatusText(const TFLI2C_t *dev);
uint8_t           TFLI2C_GetStatus(const TFLI2C_t *dev);
HAL_StatusTypeDef TFLI2C_GetHALStatus(const TFLI2C_t *dev);

#ifdef __cplusplus
}
#endif
#endif /* TFLI2C_H */
