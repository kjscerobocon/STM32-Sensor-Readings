/* TFLI2C for STM32 (HAL, plain C) - port of Bud Ryerson's Arduino library. */
#include "TFLI2C.h"

static bool ReadBytes(TFLI2C_t *dev, uint8_t reg, uint8_t addr,
                      uint8_t *data, uint16_t len)
{
    if (!dev || !dev->hi2c || !data || !len) {
        if (dev) { dev->tfStatus = TFL_INVALID; dev->halStatus = HAL_ERROR; }
        return false;
    }
    dev->halStatus = HAL_I2C_Mem_Read(dev->hi2c, (uint16_t)(addr << 1), reg,
                                      I2C_MEMADD_SIZE_8BIT, data, len,
                                      dev->timeoutMs);
    if (dev->halStatus == HAL_OK) { dev->tfStatus = TFL_READY; return true; }
    dev->tfStatus = (dev->halStatus == HAL_TIMEOUT) ? TFL_TIMEOUT : TFL_I2CREAD;
    return false;
}

static bool WriteBytes(TFLI2C_t *dev, uint8_t reg, uint8_t addr,
                       uint8_t *data, uint16_t len)
{
    if (!dev || !dev->hi2c || !data || !len) {
        if (dev) { dev->tfStatus = TFL_INVALID; dev->halStatus = HAL_ERROR; }
        return false;
    }
    dev->halStatus = HAL_I2C_Mem_Write(dev->hi2c, (uint16_t)(addr << 1), reg,
                                       I2C_MEMADD_SIZE_8BIT, data, len,
                                       dev->timeoutMs);
    if (dev->halStatus == HAL_OK) { dev->tfStatus = TFL_READY; return true; }
    dev->tfStatus = (dev->halStatus == HAL_TIMEOUT) ? TFL_TIMEOUT : TFL_I2CWRITE;
    return false;
}

bool TFLI2C_Begin(TFLI2C_t *dev, I2C_HandleTypeDef *hi2c, uint32_t timeoutMs)
{
    if (!dev) return false;
    dev->hi2c      = hi2c;
    dev->timeoutMs = timeoutMs;
    dev->regReply  = 0;
    dev->tfStatus  = (hi2c && timeoutMs) ? TFL_READY : TFL_INVALID;
    dev->halStatus = (hi2c && timeoutMs) ? HAL_OK : HAL_ERROR;
    return dev->tfStatus == TFL_READY;
}

bool TFLI2C_IsPresent(TFLI2C_t *dev, uint8_t addr)
{
    if (!dev || !dev->hi2c) return false;
    dev->halStatus = HAL_I2C_IsDeviceReady(dev->hi2c, (uint16_t)(addr << 1), 2, 10);
    dev->tfStatus  = (dev->halStatus == HAL_OK) ? TFL_READY : TFL_I2CREAD;
    return dev->halStatus == HAL_OK;
}

bool TFLI2C_ReadReg(TFLI2C_t *dev, uint8_t reg, uint8_t addr)
{
    uint8_t v = 0;
    if (!ReadBytes(dev, reg, addr, &v, 1)) return false;
    dev->regReply = v;
    return true;
}

bool TFLI2C_WriteReg(TFLI2C_t *dev, uint8_t reg, uint8_t addr, uint8_t data)
{
    return WriteBytes(dev, reg, addr, &data, 1);
}

bool TFLI2C_GetDataFull(TFLI2C_t *dev, int16_t *dist, int16_t *flux,
                        int16_t *temp, uint8_t addr)
{
    uint8_t d[6];
    if (!dist || !flux || !temp) { if (dev) dev->tfStatus = TFL_INVALID; return false; }
    if (!ReadBytes(dev, TFL_DIST_LO, addr, d, 6)) return false;

    uint16_t amp = (uint16_t)(d[2] | (d[3] << 8));
    *dist = (int16_t)(uint16_t)(d[0] | (d[1] << 8));
    *flux = (int16_t)amp;
    *temp = (int16_t)(uint16_t)(d[4] | (d[5] << 8));

    if (amp == 0xFFFF)  { dev->tfStatus = TFL_STRONG; return false; }
    if (amp < 100)      { dev->tfStatus = TFL_WEAK;   return false; }
    dev->tfStatus = TFL_READY;
    return true;
}

bool TFLI2C_GetData(TFLI2C_t *dev, int16_t *dist, uint8_t addr)
{
    int16_t flux, temp;
    return TFLI2C_GetDataFull(dev, dist, &flux, &temp, addr);
}

bool TFLI2C_Get_Time(TFLI2C_t *dev, uint16_t *tim, uint8_t addr)
{
    uint8_t d[2];
    if (!tim || !ReadBytes(dev, TFL_TICK_LO, addr, d, 2)) return false;
    *tim = (uint16_t)(d[0] | (d[1] << 8));
    return true;
}

bool TFLI2C_Get_Prod_Code(TFLI2C_t *dev, uint8_t cod[14], uint8_t addr)
{ return ReadBytes(dev, 0x10, addr, cod, 14); }

bool TFLI2C_Get_Firmware_Version(TFLI2C_t *dev, uint8_t ver[3], uint8_t addr)
{ return ReadBytes(dev, TFL_VER_REV, addr, ver, 3); }

bool TFLI2C_Get_Frame_Rate(TFLI2C_t *dev, uint16_t *frm, uint8_t addr)
{
    uint8_t d[2];
    if (!frm || !ReadBytes(dev, TFL_FPS_LO, addr, d, 2)) return false;
    *frm = (uint16_t)(d[0] | (d[1] << 8));
    return true;
}

bool TFLI2C_Set_Frame_Rate(TFLI2C_t *dev, uint16_t frm, uint8_t addr)
{
    uint8_t d[2] = { (uint8_t)(frm & 0xFF), (uint8_t)(frm >> 8) };
    return WriteBytes(dev, TFL_FPS_LO, addr, d, 2);
}

bool TFLI2C_Set_I2C_Addr(TFLI2C_t *dev, uint8_t newAddr, uint8_t addr)
{
    if (newAddr < 0x08 || newAddr > 0x77) {
        if (dev) dev->tfStatus = TFL_INVALID;
        return false;
    }
    return TFLI2C_WriteReg(dev, TFL_SET_I2C_ADDR, addr, newAddr);
}

bool TFLI2C_Save_Settings(TFLI2C_t *d, uint8_t a) { return TFLI2C_WriteReg(d, TFL_SAVE_SETTINGS,  a, 1); }
bool TFLI2C_Soft_Reset(TFLI2C_t *d, uint8_t a)    { return TFLI2C_WriteReg(d, TFL_SOFT_RESET,    a, 2); }
bool TFLI2C_Hard_Reset(TFLI2C_t *d, uint8_t a)    { return TFLI2C_WriteReg(d, TFL_HARD_RESET,    a, 1); }
bool TFLI2C_Set_Enable(TFLI2C_t *d, uint8_t a)    { return TFLI2C_WriteReg(d, TFL_DISABLE,       a, 1); }
bool TFLI2C_Set_Disable(TFLI2C_t *d, uint8_t a)   { return TFLI2C_WriteReg(d, TFL_DISABLE,       a, 0); }
bool TFLI2C_Set_Cont_Mode(TFLI2C_t *d, uint8_t a) { return TFLI2C_WriteReg(d, TFL_SET_TRIG_MODE, a, 0); }
bool TFLI2C_Set_Trig_Mode(TFLI2C_t *d, uint8_t a) { return TFLI2C_WriteReg(d, TFL_SET_TRIG_MODE, a, 1); }
bool TFLI2C_Set_Trigger(TFLI2C_t *d, uint8_t a)   { return TFLI2C_WriteReg(d, TFL_TRIGGER,       a, 1); }

uint8_t           TFLI2C_GetStatus(const TFLI2C_t *dev)    { return dev->tfStatus; }
HAL_StatusTypeDef TFLI2C_GetHALStatus(const TFLI2C_t *dev) { return dev->halStatus; }

const char *TFLI2C_GetStatusText(const TFLI2C_t *dev)
{
    switch (dev->tfStatus) {
    case TFL_READY:    return "READY";
    case TFL_TIMEOUT:  return "TIMEOUT";
    case TFL_I2CREAD:  return "I2C-READ";
    case TFL_I2CWRITE: return "I2C-WRITE";
    case TFL_WEAK:     return "Signal weak";
    case TFL_STRONG:   return "Signal strong";
    case TFL_INVALID:  return "Invalid argument / not initialised";
    default:           return "OTHER";
    }
}
